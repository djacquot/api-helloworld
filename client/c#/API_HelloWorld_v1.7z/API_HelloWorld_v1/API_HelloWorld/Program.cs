﻿using Newtonsoft.Json;
using System;
using System.IO;
using System.Net;
using System.Net.Http;

namespace PocPartenaire
{
    class Program
    {
        /// <summary>
        /// Constantes
        /// </summary>
        // /!\ AUTHORIZATION nécessite un algorithme permettant de générer le token JWT. /!\
        private const string AUTHORIZATION = "eyJhbGciOiJSUzI1NiJ9.eyJpYXQiOjE1MTk5MTU2ODR9.kcucpTIRQihea6u4kzZGfdb-uzb3KR2-G-KLiznbHMnJqTBd1JREqM4qoua69_38lxsvqHwa8020_Pmy3IoIdRLjGOzP9hc2LsJCqbCfhs5BwvzazRNtW-FQFKOl82s3Bjx1D9XG_8koin7jhc8tI7OTCfVugetVD8ogMqf3MPEB-g8dyuu02sI0Y9K3-5M3yQwa-L0rehrjmMEV7iRJMYok921PdCWWj01XF0LuWqe-zQk_dbjvhNwF45JJi8cvF9zkHUh4XrCn9cbSOcjiBQDS_xOxSExo4oBdOoUk-Td0whjEeUPuHKeAc_IUIQMGYRfhA9IIq5s7jCv8aiT6OA";
        private const string XCLIENTCERT = "MIIDYDCCAkgCCQDb4NNhXdxX1TANBgkqhkiG9w0BAQsFADByMQswCQYDVQQGEwJGUjEPMA0GA1UECAwGQ2VudHJlMRAwDgYDVQQHDAdPcmxlYW5zMRQwEgYDVQQKDAtTb3ByYVN0ZXJpYTEUMBIGA1UECwwLU29wcmFTdGVyaWExFDASBgNVBAMMC1NvcHJhU3RlcmlhMB4XDTE4MDMwMTEwNDMyM1oXDTQyMDIyMzEwNDMyM1owcjELMAkGA1UEBhMCRlIxDzANBgNVBAgMBkNlbnRyZTEQMA4GA1UEBwwHT3JsZWFuczEUMBIGA1UECgwLU29wcmFTdGVyaWExFDASBgNVBAsMC1NvcHJhU3RlcmlhMRQwEgYDVQQDDAtTb3ByYVN0ZXJpYTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAK8i5+1jvwDQg2/utajT2f2wfTsDQEY+NWQNoDAVFLUh3LFNOYA2neN4hJzqyjtL2h2Ga99gvXFeSE42Uyo/9s5gCUQ4gC7db1deybSQVJUi29RA1Jjy+hUo7PgdWVkRy6EkUwiXrBdIGc7WWibE0C93bj1Am9formKFOqt4tRXz6NXUDYzBcIeEcaFjEGBV5BRSpvddAQTfJPzDmjIVTa2n2UHSl4UG0sECBgJoXE8H+BgwrtEohWscJpDpjjWBhBWBMWEC2rh/UzwSRDQysg0R0D6qbOODxsMhpQ9pVC649998ln27rDFrMSvPs5mANVUw0xx24e+xL2qU0nrFmckCAwEAATANBgkqhkiG9w0BAQsFAAOCAQEAnzclV2xEivcPOoK/NHtkg57GVu8DonWASNF3H03SzaRVIKwibViOMmI12/RyEEAI/eSOsxVZmzp8sh29vr2dP0bxauPrvVSvXkpPSATkSk3H7FrR2ks1+bejHBILEDQwSC3mDyB0UUNV9J+UkPCgY6mn+pSDTz33VGMh0kJruhPul/9zyNeJIr0Wun8TKNJ5k1NIioWPo9loB5YwwZwghf7jKcKzLHgC73v/M43ppS5xoX/V1Xz+VQPhliAbISLcsgQTXlKoSQO9HW1gG1t7084ZD3UDWPFYUMr3VT0HekBmEDDU/ZBtuZqPHq7Zlb6P/Co5Z8WObOmES5gdo5ALZA==";
        private const string APIKEY = "l7xxbd648791bb6e4dc886873cf4af5d44c5";
        private const string APIURL = "https://hom-api.mutuellegenerale.com/APIMGT_TEST/test/V1/helloworld/";

        /// <summary>
        /// Main
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            Uri uri = new Uri(APIURL);

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(new Uri(APIURL));
            request.Method = HttpMethod.Get.Method;
            request.Host = uri.Host;
            request.KeepAlive = true;

            request.Headers.Add("Authorization", AUTHORIZATION);
            request.Headers.Add("x-client-cert", XCLIENTCERT);
            request.Headers.Add("api-key", APIKEY);

            string responseString;
            HelloWorldResponse helloWorldResponse = null;

            try
            {
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                    JsonSerializer jsonSerializer = new JsonSerializer();

                    using (StringReader reader = new StringReader(responseString))
                    {
                        using (JsonTextReader jsonTextReader = new JsonTextReader(reader))
                        {
                            helloWorldResponse = jsonSerializer.Deserialize<HelloWorldResponse>(jsonTextReader);
                        }
                    }
                }
            }
            catch (WebException ex)
            {
                if (ex.Response == null)
                {
                    throw new Exception(ex.Message, ex);
                }

                HttpWebResponse httpWebResponse = (HttpWebResponse)ex.Response;
                Stream stream = ex.Response.GetResponseStream();
                responseString = new StreamReader(stream).ReadToEnd();

                Console.WriteLine(responseString);
            }
            catch (JsonSerializationException ex)
            {
                throw new Exception("Erreur de désérialisation json : " + ex.Message, ex);
            }

            Console.WriteLine(helloWorldResponse != null ? string.Format("{0}, {1}", helloWorldResponse?.Message, helloWorldResponse?.Resultat) : "Une erreur est survenue");

            Console.ReadKey();
        }
    }
}
